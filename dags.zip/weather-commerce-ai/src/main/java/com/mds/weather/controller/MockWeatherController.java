package com.mds.weather.controller;

import com.mds.weather.service.MockWeatherService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Mock 날씨 데이터 관리 API
 *
 * <p>엔드포인트:
 * <pre>
 *   GET  /api/mock/status           현재 데이터 현황 + AI API 준비 상태
 *   POST /api/mock/generate         지금 즉시 날씨 생성 (4개 도시)
 *   POST /api/mock/seed?days=7      N일치 히스토리 시딩
 *   GET  /api/mock/latest           최신 도시별 날씨 요약
 * </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/mock")
@RequiredArgsConstructor
public class MockWeatherController {

    private final MockWeatherService mockWeatherService;

    // ── 상태 확인 ─────────────────────────────────────────────
    /**
     * 전체 데이터 현황 및 AI API 준비 상태 확인
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        int total   = mockWeatherService.countRecords();
        boolean ready = total > 0;

        Map<String, Object> res = new LinkedHashMap<>();
        res.put("status",        ready ? "✅ READY" : "⚠️ NO_DATA");
        res.put("totalRecords",  total);
        res.put("cities",        MockWeatherService.CITIES);
        res.put("checkedAt",     LocalDateTime.now().toString());
        res.put("aiApis", Map.of(
            "recommend", ready ? "✅ 사용 가능" : "❌ 데이터 필요",
            "chat",      ready ? "✅ 사용 가능 (배치 후 RAG 가능)" : "❌ 데이터 필요",
            "report",    ready ? "✅ 사용 가능 (배치 후)" : "❌ 데이터 필요"
        ));
        res.put("hint", ready
            ? "POST /api/batch/run/weather-analysis 실행 후 /api/report 사용 가능"
            : "POST /api/mock/seed 를 먼저 실행하세요");

        return ResponseEntity.ok(res);
    }

    // ── 즉시 생성 ─────────────────────────────────────────────
    /**
     * 현재 시각 기준 모든 도시 날씨 즉시 생성
     */
    @PostMapping("/generate")
    public ResponseEntity<Map<String, Object>> generate() {
        log.info("[MockAPI] 날씨 즉시 생성 요청");
        int count = mockWeatherService.generateAll();

        return ResponseEntity.ok(Map.of(
            "message",          "4개 도시 현재 날씨 생성 완료",
            "citiesGenerated",  count,
            "cities",           MockWeatherService.CITIES,
            "generatedAt",      LocalDateTime.now().toString(),
            "nextStep",         "GET /api/mock/latest 로 결과 확인"
        ));
    }

    // ── 히스토리 시딩 ─────────────────────────────────────────
    /**
     * N일치 과거 날씨 데이터 일괄 생성 (6시간 간격)
     *
     * @param days 생성할 과거 일수 (기본 7)
     */
    @PostMapping("/seed")
    public ResponseEntity<Map<String, Object>> seed(
            @RequestParam(defaultValue = "7") int days) {

        log.info("[MockAPI] {}일치 히스토리 시딩 시작", days);
        long start = System.currentTimeMillis();
        int  count = mockWeatherService.seedHistory(days);
        long ms    = System.currentTimeMillis() - start;

        return ResponseEntity.ok(Map.of(
            "message",         days + "일치 날씨 히스토리 생성 완료",
            "daysGenerated",   days,
            "recordsInserted", count,
            "elapsedMs",       ms,
            "nextSteps",       List.of(
                "1. POST /api/batch/run/weather-analysis (날씨-매출 분석)",
                "2. POST /api/batch/run/embedding-index  (RAG 인덱스 생성)",
                "3. GET  /api/recommend?city=Seoul&customerId=1",
                "4. POST /api/chat  {\"question\":\"비 올때 잘 팔린 상품은?\"}",
                "5. GET  /api/report?days=7"
            )
        ));
    }

    // ── 최신 날씨 조회 ────────────────────────────────────────
    /**
     * 도시별 최신 날씨 1건씩 요약 반환
     */
    @GetMapping("/latest")
    public ResponseEntity<Map<String, Object>> latest() {
        List<Map<String, Object>> rows = mockWeatherService.getLatestSummary();

        return ResponseEntity.ok(Map.of(
            "count",    rows.size(),
            "weather",  rows,
            "queriedAt", LocalDateTime.now().toString()
        ));
    }
}
