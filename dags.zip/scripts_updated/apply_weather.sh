#!/bin/bash
# ============================================================
# apply_weather.sh
# 기존 MDS Docker 환경에 Weather 기능을 추가하는 스크립트
#
# 실행 방법:
#   chmod +x apply_weather.sh
#   ./apply_weather.sh YOUR_API_KEY
#
# 사전 조건:
#   - docker compose up -d 로 기존 MDS 스택이 실행 중
#   - mds_postgres, mds_airflow_web 컨테이너가 healthy 상태
# ============================================================

set -e

# ──────────────────────────────────────────────
# 인자 처리
# ──────────────────────────────────────────────
API_KEY="${1:-}"
if [ -z "$API_KEY" ]; then
    echo ""
    echo "  사용법: ./apply_weather.sh <YOUR_OPENWEATHER_API_KEY>"
    echo ""
    echo "  API 키 발급: https://openweathermap.org/api"
    echo "  (무료 가입 후 API Keys 탭에서 복사)"
    echo ""
    exit 1
fi

POSTGRES_CONTAINER="mds_postgres"
AIRFLOW_CONTAINER="mds_airflow_web"
SQL_FILE="./scripts/weather_init.sql"
DAGS_DIR="./dags"
DEST_DAG="${DAGS_DIR}/weather_etl_dag.py"

# DAG 소스 파일 탐색 순서:
#   1) 스크립트와 같은 폴더(루트)에 있는 weather_etl_dag.py
#   2) weather-addon/dags/ 하위
#   3) 이미 dags/ 안에 있는 경우 → 복사 스킵
if   [ -f "./weather_etl_dag.py" ];              then DAG_FILE="./weather_etl_dag.py"
elif [ -f "./weather-addon/dags/weather_etl_dag.py" ]; then DAG_FILE="./weather-addon/dags/weather_etl_dag.py"
elif [ -f "$DEST_DAG" ];                          then DAG_FILE="$DEST_DAG"   # 이미 제자리
else DAG_FILE=""; fi

# 색상
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

log_step() { echo -e "${CYAN}[STEP]${NC} $1"; }
log_ok()   { echo -e "${GREEN}[ OK ]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_err()  { echo -e "${RED}[ERR ]${NC} $1"; exit 1; }

echo ""
echo "======================================================="
echo "  Weather ETL 추가 설치 스크립트"
echo "  (기존 MDS 환경: postgres + airflow + superset)"
echo "======================================================="
echo ""

# ──────────────────────────────────────────────
# STEP 1: 컨테이너 상태 확인
# ──────────────────────────────────────────────
log_step "1/5  컨테이너 상태 확인..."

if ! docker ps --format '{{.Names}}' | grep -q "^${POSTGRES_CONTAINER}$"; then
    log_err "PostgreSQL 컨테이너(${POSTGRES_CONTAINER})가 실행 중이지 않습니다. 'docker compose up -d' 먼저 실행하세요."
fi

if ! docker ps --format '{{.Names}}' | grep -q "^${AIRFLOW_CONTAINER}$"; then
    log_err "Airflow 컨테이너(${AIRFLOW_CONTAINER})가 실행 중이지 않습니다."
fi

log_ok "컨테이너 정상 실행 확인"

# ──────────────────────────────────────────────
# STEP 2: weather 스키마 + 테이블 생성
# ──────────────────────────────────────────────
log_step "2/5  PostgreSQL weather 스키마 초기화..."

if [ ! -f "$SQL_FILE" ]; then
    log_err "SQL 파일이 없습니다: ${SQL_FILE}"
fi

# SQL 파일을 컨테이너에 복사 후 실행
docker cp "$SQL_FILE" "${POSTGRES_CONTAINER}:/tmp/weather_init.sql"
docker exec "${POSTGRES_CONTAINER}" \
    psql -U airflow -d airflow -f /tmp/weather_init.sql

log_ok "weather 스키마 및 테이블 생성 완료"

# ──────────────────────────────────────────────
# STEP 3: Airflow DAG 파일 배포
# ──────────────────────────────────────────────
log_step "3/5  DAG 파일 배포..."

# dags 디렉토리 존재 확인
if [ ! -d "$DAGS_DIR" ]; then
    log_err "dags 디렉토리를 찾을 수 없습니다: ${DAGS_DIR}  (프로젝트 루트에서 실행하세요)"
fi

# DAG 소스를 찾지 못한 경우
if [ -z "$DAG_FILE" ]; then
    log_err "weather_etl_dag.py 를 찾을 수 없습니다.\n  다음 위치 중 하나에 파일을 두세요:\n    ① 프로젝트 루트  ./weather_etl_dag.py\n    ② ./weather-addon/dags/weather_etl_dag.py\n    ③ ./dags/weather_etl_dag.py (이미 배포된 경우)"
fi

# 소스와 대상이 같은 파일이면 복사 스킵
if [ "$(realpath "$DAG_FILE")" = "$(realpath "$DEST_DAG" 2>/dev/null || echo "__none__")" ]; then
    log_ok "DAG 파일이 이미 제자리에 있습니다: ${DEST_DAG} (복사 스킵)"
else
    # 대상에 이미 파일이 있으면 백업
    if [ -f "$DEST_DAG" ]; then
        cp "$DEST_DAG" "${DEST_DAG}.bak"
        log_warn "기존 DAG 파일 백업: ${DEST_DAG}.bak"
    fi
    cp "$DAG_FILE" "$DEST_DAG"
    log_ok "DAG 파일 배포 완료: ${DEST_DAG}"
fi

# ──────────────────────────────────────────────
# STEP 4: Airflow Connection 등록
# ──────────────────────────────────────────────
log_step "4/5  Airflow Connection 등록 (weathermap_api)..."

# 기존 Connection 있으면 삭제 후 재등록
docker exec "${AIRFLOW_CONTAINER}" \
    airflow connections delete weathermap_api 2>/dev/null || true

docker exec "${AIRFLOW_CONTAINER}" \
    airflow connections add weathermap_api \
    --conn-type http \
    --conn-host "https://api.openweathermap.org"

log_ok "Connection 'weathermap_api' 등록 완료"

# ──────────────────────────────────────────────
# STEP 5: Airflow Variable 등록
# ──────────────────────────────────────────────
log_step "5/5  Airflow Variable 등록..."

# openweather_api_key
docker exec "${AIRFLOW_CONTAINER}" \
    airflow variables set openweather_api_key "${API_KEY}"
log_ok "Variable 'openweather_api_key' 등록 완료"

# weather_cities (기본값)
docker exec "${AIRFLOW_CONTAINER}" \
    airflow variables set weather_cities "Seoul,Busan,Incheon,Daegu"
log_ok "Variable 'weather_cities' 등록 완료 (Seoul,Busan,Incheon,Daegu)"

# ──────────────────────────────────────────────
# 완료 요약
# ──────────────────────────────────────────────
echo ""
echo "======================================================="
echo -e "  ${GREEN}✅ Weather ETL 추가 설치 완료!${NC}"
echo "======================================================="
echo ""
echo "  다음 단계:"
echo ""
echo "  1) Airflow UI 접속 → DAG 활성화"
echo "     http://localhost:8080"
echo "     admin / admin"
echo "     → DAGs → 'weather_etl_pipeline' Toggle ON"
echo "     → ▶ Trigger DAG (즉시 실행)"
echo ""
echo "  2) 데이터 수집 확인"
echo "     docker exec mds_postgres psql -U airflow -d airflow \\"
echo "       -c \"SELECT city, temperature_c, humidity_pct, collected_at"
echo "            FROM weather.weather_data ORDER BY collected_at DESC LIMIT 10;\""
echo ""
echo "  3) Superset 대시보드 설정"
echo "     http://localhost:8088  (admin / admin)"
echo "     → Settings → Database Connections"
echo "     → 기존 postgres 연결에서 weather 스키마 사용"
echo ""
echo "  ℹ️  도시 변경: Airflow UI → Admin → Variables → weather_cities"
echo "      예: Seoul,Busan,Jeju,Suwon"
echo ""
