C:\Projects\data-stack\docker-compose.yml

C:\Projects\data-stack\Dockerfile.airflow

C:\Projects\data-stack\scripts\init-db.sql

docker compose exec airflow-scheduler bash -c "dbt --version"
docker compose exec airflow-scheduler bash -c "cd /opt/dbt && dbt debug --profiles-dir /opt/dbt --project-dir /opt/dbt"
docker compose exec airflow-scheduler bash -c "cd /opt/dbt && dbt run --select staging --profiles-dir /opt/dbt --project-dir /opt/dbt"
docker compose exec airflow-scheduler bash -c "cd /opt/dbt && dbt run --select marts --profiles-dir /opt/dbt --project-dir /opt/dbt"
docker compose exec airflow-scheduler bash -c "cd /opt/dbt && dbt test --profiles-dir /opt/dbt --project-dir /opt/dbt"

C:\Projects\data-stack\
├─ docker-compose.yml
├─ Dockerfile.airflow
├─ dags\
├─ logs\
├─ plugins\
├─ dbt_project\
│  ├─ dbt_project.yml
│  ├─ profiles.yml
│  └─ models\
├─ scripts\
│  └─ init-db.sql
└─ superset_config\
   └─ superset_config.py

mkdir dags, logs, plugins, dbt_project, scripts, superset_config
mkdir dbt_project\models
mkdir dbt_project\models\staging
mkdir dbt_project\models\marts


cd C:\Projects\data-stack
docker compose down -v
docker compose build --no-cache
docker compose up airflow-init
docker compose up -d


----------------pgvector 추가

# 컨테이너 재생성 (볼륨은 유지됨)
docker compose up -d --force-recreate postgres

# pgvector 확장 활성화 (1회만)
docker exec mds_postgres psql -U airflow -d airflow \
  -c "CREATE EXTENSION IF NOT EXISTS vector;"

# 확인
docker exec mds_postgres psql -U airflow -d airflow \
  -c "SELECT extversion FROM pg_extension WHERE extname = 'vector';"
# → 0.7.x 출력되면 성공

---------------------------------------.yml
# docker-compose.yml — postgres 서비스 이미지만 교체
postgres:
  image: pgvector/pgvector:pg15   # ← postgres:15 에서 변경
  container_name: mds_postgres
  # 나머지 설정 그대로 유지
  volumes:
    - postgres_data:/var/lib/postgresql/data   # ← 볼륨 그대로 → 데이터 보존
    - ./scripts/init-db.sql:/docker-entrypoint-initdb.d/init-db.sql








docker exec mds_postgres psql -U airflow -d airflow -c "CREATE EXTENSION IF NOT EXISTS vector;"
docker exec mds_postgres psql -U airflow -d airflow -c "ALTER DATABASE airflow REFRESH COLLATION VERSION;"
docker exec mds_postgres psql -U airflow -d airflow  -c "ALTER DATABASE airflow REFRESH COLLATION VERSION;"

docker exec mds_postgres psql -U airflow -d airflow  -c "SELECT extname, extversion FROM pg_extension WHERE extname = 'vector';"

# 1. postgres 이미지 교체 (docker-compose.yml 1줄)
#    postgres:15  →  pgvector/pgvector:pg15
docker compose up -d --force-recreate postgres
docker exec mds_postgres psql -U airflow -d airflow \
  -c "CREATE EXTENSION IF NOT EXISTS vector;"

# 2. Ollama 시작
docker compose -f docker-compose.yml -f docker-compose.ollama.yml up -d ollama

# 3. 모델 다운로드 (~2.3GB, 30분 이내)
docker exec -it mds_ollama ollama pull llama3.2
docker exec -it mds_ollama ollama pull nomic-embed-text

# 4. analytics 스키마 생성
docker cp scripts/analytics_schema.sql mds_postgres:/tmp/
docker exec mds_postgres psql -U airflow -d airflow -f /tmp/analytics_schema.sql

# 5. Spring Boot 실행 (포트 8090)
cd weather-commerce-ai && gradle wrapper && ./gradlew bootRun

docker compose -f docker-compose.yml -f docker-compose.ollama.yml up -d ollama
# 모델 다운로드 (별도 터미널, 시간 소요)
docker exec -it mds_ollama ollama pull llama3.2
docker exec -it mds_ollama ollama pull nomic-embed-text

# analytics 스키마 생성
docker cp scripts/analytics_schema.sql mds_postgres:/tmp/
docker exec mds_postgres psql -U airflow -d airflow -f /tmp/analytics_schema.sql




