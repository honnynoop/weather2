package com.mds.weather.controller;

import com.mds.weather.service.WeatherChatService;
import com.mds.weather.service.WeatherRecommendationService;
import com.mds.weather.service.WeatherReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

// ============================================================
//  RecommendationController  GET /api/recommend
// ============================================================

/**
 * 날씨 기반 AI 상품 추천 API
 *
 * <p>예시:
 * <pre>
 *   GET /api/recommend?city=Seoul&customerId=1
 *   GET /api/recommend/anonymous?city=Busan
 * </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/recommend")
@RequiredArgsConstructor
class RecommendationController {

    private final WeatherRecommendationService recommendService;

    /** 고객 맞춤 추천 (구매 이력 반영) */
    @GetMapping
    public ResponseEntity<Map<String, Object>> recommend(
            @RequestParam String city,
            @RequestParam Long   customerId) {

        log.info("[API] 추천 요청: city={} customerId={}", city, customerId);
        String result = recommendService.recommend(city, customerId);
        return ResponseEntity.ok(Map.of(
                "city",       city,
                "customerId", customerId,
                "recommendation", result,
                "generatedAt", LocalDateTime.now().toString()
        ));
    }

    /** 비로그인 사용자 추천 (날씨만 반영) */
    @GetMapping("/anonymous")
    public ResponseEntity<Map<String, Object>> recommendAnonymous(
            @RequestParam String city) {

        log.info("[API] 익명 추천 요청: city={}", city);
        String result = recommendService.recommendByWeatherOnly(city);
        return ResponseEntity.ok(Map.of(
                "city",           city,
                "recommendation", result,
                "generatedAt",    LocalDateTime.now().toString()
        ));
    }
}

// ============================================================
//  ChatController  POST /api/chat
// ============================================================

/**
 * 날씨-매출 RAG 채팅 API
 *
 * <p>예시:
 * <pre>
 *   POST /api/chat
 *   { "question": "비 올 때 어떤 상품이 잘 팔렸어?" }
 *
 *   POST /api/chat/city
 *   { "question": "기온이 30도 이상일 때 매출은?", "city": "Seoul" }
 * </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
class ChatController {

    private final WeatherChatService chatService;

    record ChatRequest(String question) {}
    record ChatWithCityRequest(String question, String city) {}

    /** 전체 데이터 기반 RAG Q&A */
    @PostMapping
    public ResponseEntity<Map<String, Object>> chat(
            @RequestBody ChatRequest req) {

        log.info("[API] 채팅 요청: {}", req.question());
        String answer = chatService.chat(req.question());
        return ResponseEntity.ok(Map.of(
                "question",    req.question(),
                "answer",      answer,
                "answeredAt",  LocalDateTime.now().toString()
        ));
    }

    /** 도시 필터 RAG Q&A */
    @PostMapping("/city")
    public ResponseEntity<Map<String, Object>> chatWithCity(
            @RequestBody ChatWithCityRequest req) {

        log.info("[API] 도시 채팅 요청: {} ({})", req.question(), req.city());
        String answer = chatService.chatWithCityFilter(req.question(), req.city());
        return ResponseEntity.ok(Map.of(
                "question",   req.question(),
                "city",       req.city(),
                "answer",     answer,
                "answeredAt", LocalDateTime.now().toString()
        ));
    }
}

// ============================================================
//  ReportController  GET /api/report
// ============================================================

/**
 * AI 인사이트 리포트 API
 *
 * <p>예시:
 * <pre>
 *   GET /api/report?days=7
 *   GET /api/report/city?city=Seoul
 * </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/report")
@RequiredArgsConstructor
class ReportController {

    private final WeatherReportService reportService;

    /** 기간별 전체 리포트 */
    @GetMapping
    public ResponseEntity<Map<String, Object>> report(
            @RequestParam(defaultValue = "7") int days) {

        log.info("[API] 리포트 요청: 최근 {}일", days);
        String report = reportService.generateReport(days);
        return ResponseEntity.ok(Map.of(
                "period",      days + "일",
                "report",      report,
                "generatedAt", LocalDateTime.now().toString()
        ));
    }

    /** 도시별 리포트 */
    @GetMapping("/city")
    public ResponseEntity<Map<String, Object>> cityReport(
            @RequestParam String city) {

        log.info("[API] 도시 리포트 요청: {}", city);
        String report = reportService.generateCityReport(city);
        return ResponseEntity.ok(Map.of(
                "city",        city,
                "report",      report,
                "generatedAt", LocalDateTime.now().toString()
        ));
    }
}

// ============================================================
//  BatchController  POST /api/batch/run/{jobName}
// ============================================================

/**
 * 배치 Job 수동 실행 API
 *
 * <p>예시:
 * <pre>
 *   POST /api/batch/run/weather-analysis
 *   POST /api/batch/run/embedding-index
 * </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/batch")
@RequiredArgsConstructor
class BatchController {

    private final JobLauncher jobLauncher;
    private final Job         weatherAnalysisJob;
    private final Job         embeddingIndexJob;

    @PostMapping("/run/{jobName}")
    public ResponseEntity<Map<String, Object>> runBatch(
            @PathVariable String jobName) throws Exception {

        Job job = switch (jobName) {
            case "weather-analysis" -> weatherAnalysisJob;
            case "embedding-index"  -> embeddingIndexJob;
            default -> throw new IllegalArgumentException(
                    "알 수 없는 Job: " + jobName +
                    " (사용 가능: weather-analysis, embedding-index)");
        };

        JobParameters params = new JobParametersBuilder()
                .addString("runAt", LocalDateTime.now().toString())
                .addString("triggeredBy", "manual-api")
                .toJobParameters();

        log.info("[API] 배치 수동 실행: {}", jobName);
        JobExecution execution = jobLauncher.run(job, params);

        return ResponseEntity.ok(Map.of(
                "jobName",   jobName,
                "status",    execution.getStatus().toString(),
                "startTime", LocalDateTime.now().toString()
        ));
    }
}
