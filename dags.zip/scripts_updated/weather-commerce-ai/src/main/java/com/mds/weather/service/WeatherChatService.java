package com.mds.weather.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.QuestionAnswerAdvisor;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

/**
 * 날씨 × 매출 RAG(Retrieval-Augmented Generation) 채팅 서비스
 *
 * <p>동작 원리:
 * <ol>
 *   <li>사용자 질문을 nomic-embed-text 로 임베딩</li>
 *   <li>PgVectorStore 에서 코사인 유사도 기준 상위 5개 문서 검색</li>
 *   <li>검색된 날씨/분석 데이터를 컨텍스트에 포함해 llama3.2 에 전달</li>
 *   <li>LLM이 컨텍스트 기반으로 자연어 답변 생성</li>
 * </ol>
 *
 * <p>예시 질문:
 * <ul>
 *   <li>"비 오는 날 어떤 상품이 잘 팔렸어?"</li>
 *   <li>"서울이 35도 이상일 때 매출 트렌드는?"</li>
 *   <li>"겨울철 인천 날씨와 스포츠용품 판매의 관계는?"</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WeatherChatService {

    private final ChatClient chatClient;
    private final VectorStore vectorStore;

    /**
     * RAG 기반 날씨-매출 Q&A
     *
     * @param question 사용자 질문
     * @return LLM 생성 답변
     */
    public String chat(String question) {
        log.debug("[RAG Chat] 질문: {}", question);

        return chatClient.prompt()
                .advisors(QuestionAnswerAdvisor.builder(vectorStore)
                        .searchRequest(SearchRequest.builder()
                                .query(question)
                                .topK(5)             // 상위 5개 유사 문서 검색
                                .similarityThreshold(0.5)  // 유사도 최소 기준
                                .build())
                        .build())
                .user(question)
                .call()
                .content();
    }

    /**
     * 도시 필터를 적용한 RAG 검색
     *
     * @param question 질문
     * @param city     필터 도시 (예: "Seoul")
     */
    public String chatWithCityFilter(String question, String city) {
        log.debug("[RAG Chat] 질문: {} | 도시 필터: {}", question, city);

        // 메타데이터 필터로 특정 도시 데이터만 검색
        return chatClient.prompt()
                .advisors(QuestionAnswerAdvisor.builder(vectorStore)
                        .searchRequest(SearchRequest.builder()
                                .query(question)
                                .topK(5)
                                .filterExpression("city == '" + city + "'")
                                .build())
                        .build())
                .user(question + " (도시: " + city + "에 대해서만 답변하세요)")
                .call()
                .content();
    }
}
