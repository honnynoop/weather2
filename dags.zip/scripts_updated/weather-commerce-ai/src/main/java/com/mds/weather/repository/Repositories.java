package com.mds.weather.repository;

import com.mds.weather.domain.Customer;
import com.mds.weather.domain.Product;
import com.mds.weather.domain.SalesOrder;
import com.mds.weather.domain.WeatherData;
import com.mds.weather.domain.WeatherSalesCorr;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

// ── WeatherData ──────────────────────────────────────────────
public interface WeatherDataRepository
        extends JpaRepository<WeatherData, Long> {

    /** 특정 도시 최신 날씨 1건 */
    Optional<WeatherData> findTopByCityOrderByCollectedAtDesc(String city);

    /** 오늘 수집된 날씨 전체 */
    @Query("SELECT w FROM WeatherData w WHERE DATE(w.collectedAt) = :date")
    List<WeatherData> findByDate(@Param("date") LocalDate date);

    /** 아직 임베딩 처리되지 않은 날씨 (embedding_log 기준) */
    @Query(value = """
            SELECT w.* FROM weather.weather_data w
            WHERE NOT EXISTS (
                SELECT 1 FROM analytics.embedding_log e
                WHERE e.source_type = 'weather' AND e.source_id = w.id
            )
            ORDER BY w.collected_at DESC
            LIMIT :limit
            """, nativeQuery = true)
    List<WeatherData> findNotEmbedded(@Param("limit") int limit);
}

// ── Customer ─────────────────────────────────────────────────
public interface CustomerRepository
        extends JpaRepository<Customer, Long> {

    /** 한국어 도시명 접두어로 검색 (예: '서울%') */
    @Query("SELECT c FROM Customer c WHERE c.city LIKE :prefix%")
    List<Customer> findByCityPrefix(@Param("prefix") String prefix);
}

// ── Product ──────────────────────────────────────────────────
public interface ProductRepository
        extends JpaRepository<Product, Long> {

    List<Product> findByCategory(String category);

    /** 상품명 또는 카테고리에 키워드 포함 */
    @Query("SELECT p FROM Product p WHERE p.name LIKE %:kw% OR p.category LIKE %:kw%")
    List<Product> searchByKeyword(@Param("kw") String keyword);
}

// ── SalesOrder ───────────────────────────────────────────────
public interface SalesOrderRepository
        extends JpaRepository<SalesOrder, Long> {

    /** 특정 고객 최근 주문 */
    List<SalesOrder> findTop10ByCustomer_CustomerIdOrderByOrderDateDesc(Long customerId);

    /** 날짜 범위 완료 주문 */
    @Query("SELECT o FROM SalesOrder o WHERE o.orderDate BETWEEN :from AND :to AND o.status = 'completed'")
    List<SalesOrder> findCompletedBetween(@Param("from") LocalDate from,
                                          @Param("to")   LocalDate to);

    /** 카테고리별 매출 Top N (네이티브 SQL) */
    @Query(value = """
            SELECT p.category, COUNT(*) AS cnt,
                   SUM(o.quantity * o.unit_price * (1 - o.discount_rate)) AS revenue
            FROM raw.orders o
            JOIN raw.products p ON o.product_id = p.product_id
            WHERE o.order_date = :date AND o.status = 'completed'
            GROUP BY p.category
            ORDER BY revenue DESC
            LIMIT :topN
            """, nativeQuery = true)
    List<Object[]> findTopCategoriesByDate(@Param("date") LocalDate date,
                                            @Param("topN") int topN);
}

// ── WeatherSalesCorr ─────────────────────────────────────────
public interface WeatherSalesCorrRepository
        extends JpaRepository<WeatherSalesCorr, Long> {

    List<WeatherSalesCorr> findByCityOrderByCalcDateDesc(String city);

    @Query("SELECT w FROM WeatherSalesCorr w WHERE w.calcDate BETWEEN :from AND :to ORDER BY w.calcDate DESC")
    List<WeatherSalesCorr> findBetween(@Param("from") LocalDate from,
                                       @Param("to")   LocalDate to);

    boolean existsByCityAndCalcDate(String city, LocalDate date);
}
