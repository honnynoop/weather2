package com.mds.weather.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// ============================================================
//  Customer  —  raw.customers
// ============================================================
@Getter @NoArgsConstructor
@Entity
@Table(name = "customers", schema = "raw")
class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Long customerId;

    private String name;
    private String email;
    private String phone;
    private String city;
    private String region;

    @Column(name = "age_group") private String ageGroup;
    @Column(name = "gender")    private String gender;
    @Column(name = "channel")   private String channel;
    @Column(name = "signup_date") private LocalDate signupDate;
    @Column(name = "created_at")  private LocalDateTime createdAt;
}

// ============================================================
//  Product  —  raw.products
// ============================================================
@Getter @NoArgsConstructor
@Entity
@Table(name = "products", schema = "raw")
class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long productId;

    private String name;
    private String category;
    private String subcategory;
    private String brand;
    private BigDecimal price;
    private BigDecimal cost;

    @Column(name = "stock_qty")  private Integer  stockQty;
    @Column(name = "created_at") private LocalDateTime createdAt;
}

// ============================================================
//  SalesOrder  —  raw.orders  (Order 는 예약어라 SalesOrder 사용)
// ============================================================
@Getter @NoArgsConstructor
@Entity
@Table(name = "orders", schema = "raw")
class SalesOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private Long orderId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private Product product;

    private Integer quantity;

    @Column(name = "unit_price")    private BigDecimal unitPrice;
    @Column(name = "discount_rate") private BigDecimal discountRate;
    @Column(name = "order_date")    private LocalDate  orderDate;
    private String status;
    private String channel;
    @Column(name = "created_at")    private LocalDateTime createdAt;

    /** 실 매출액 = quantity × unitPrice × (1 - discountRate) */
    public BigDecimal getRevenue() {
        return unitPrice
                .multiply(BigDecimal.valueOf(quantity))
                .multiply(BigDecimal.ONE.subtract(
                        discountRate != null ? discountRate : BigDecimal.ZERO));
    }
}

// ============================================================
//  WeatherSalesCorr  —  analytics.weather_sales_corr
// ============================================================
@Getter @Setter @NoArgsConstructor
@Entity
@Table(name = "weather_sales_corr", schema = "analytics")
class WeatherSalesCorr {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String city;

    @Column(name = "weather_desc")  private String     weatherDesc;
    @Column(name = "avg_temp_c")    private BigDecimal avgTempC;
    @Column(name = "total_orders")  private Integer    totalOrders;
    @Column(name = "total_revenue") private BigDecimal totalRevenue;
    @Column(name = "top_category")  private String     topCategory;
    @Column(name = "calc_date")     private LocalDate  calcDate;
    @Column(name = "created_at")    private LocalDateTime createdAt;

    public static WeatherSalesCorr of(String city, String desc,
                                      BigDecimal temp, int orders,
                                      BigDecimal revenue, String category) {
        WeatherSalesCorr e = new WeatherSalesCorr();
        e.city        = city;
        e.weatherDesc = desc;
        e.avgTempC    = temp;
        e.totalOrders = orders;
        e.totalRevenue = revenue;
        e.topCategory = category;
        e.calcDate    = LocalDate.now();
        e.createdAt   = LocalDateTime.now();
        return e;
    }

    /** 프롬프트 컨텍스트용 요약 */
    public String toText() {
        return String.format(
            "[분석] 날짜:%s | 도시:%s | 날씨:%s | 기온:%.1f°C | 주문:%d건 | 매출:%,.0f원 | 인기카테고리:%s",
            calcDate, city, weatherDesc, avgTempC, totalOrders, totalRevenue, topCategory
        );
    }
}
