#!/bin/bash
# ============================================================
# apply_all.sh
# Ollama + analytics 스키마 + 모델 풀까지 한번에 설정
# 실행: ./apply_all.sh
# ============================================================
set -e

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
log_step() { echo -e "${CYAN}[STEP]${NC} $1"; }
log_ok()   { echo -e "${GREEN}[ OK ]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

echo ""
echo "=================================================="
echo "  Weather × Commerce AI 전체 환경 구성"
echo "=================================================="
echo ""

# STEP 1: analytics 스키마 생성
log_step "1/3  analytics 스키마 생성..."
docker cp scripts/analytics_schema.sql mds_postgres:/tmp/analytics_schema.sql
docker exec mds_postgres psql -U airflow -d airflow -f /tmp/analytics_schema.sql
log_ok "analytics 스키마 생성 완료"

# STEP 2: pgvector 확장 활성화 (이미 pgvector 이미지로 교체했다고 가정)
log_step "2/3  pgvector 확장 활성화..."
docker exec mds_postgres psql -U airflow -d airflow \
  -c "CREATE EXTENSION IF NOT EXISTS vector;" 2>/dev/null \
  && log_ok "pgvector 활성화 완료" \
  || log_warn "pgvector 미설치 — docker-compose에서 postgres:15 → pgvector/pgvector:pg15 로 교체 필요"

# STEP 3: Ollama 서비스 시작
log_step "3/3  Ollama 서비스 시작..."
docker compose -f docker-compose.yml -f docker-compose.ollama.yml up -d ollama

echo ""
log_ok "기본 서비스 준비 완료!"
echo ""
echo "  모델 다운로드 (별도 터미널에서 진행 — 약 2.3GB):"
echo "  docker compose -f docker-compose.yml -f docker-compose.ollama.yml up ollama-model-init"
echo ""
echo "  또는 이미 실행 중인 Ollama에 직접 풀:"
echo "  docker exec mds_ollama ollama pull llama3.2"
echo "  docker exec mds_ollama ollama pull nomic-embed-text"
echo ""
echo "  모델 준비 후 Spring Boot 앱 실행:"
echo "  cd weather-commerce-ai && ./gradlew bootRun"
echo ""
