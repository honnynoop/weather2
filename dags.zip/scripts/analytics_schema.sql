-- ============================================================
-- analytics_schema.sql
-- Spring Batch 결과 저장용 analytics 스키마 추가
-- 실행: docker exec mds_postgres psql -U airflow -d airflow -f /tmp/analytics_schema.sql
-- ============================================================

\connect airflow;

-- analytics 스키마 생성
CREATE SCHEMA IF NOT EXISTS analytics;

-- 날씨-매출 상관관계 집계 테이블
CREATE TABLE IF NOT EXISTS analytics.weather_sales_corr (
    id             SERIAL PRIMARY KEY,
    city           VARCHAR(100) NOT NULL,
    weather_desc   VARCHAR(200),
    avg_temp_c     NUMERIC(5,2),
    total_orders   INTEGER      DEFAULT 0,
    total_revenue  NUMERIC(14,2) DEFAULT 0,
    top_category   VARCHAR(100),
    calc_date      DATE         NOT NULL DEFAULT CURRENT_DATE,
    created_at     TIMESTAMP    DEFAULT NOW(),
    UNIQUE (city, calc_date)
);

CREATE INDEX IF NOT EXISTS idx_wsc_city ON analytics.weather_sales_corr(city);
CREATE INDEX IF NOT EXISTS idx_wsc_date ON analytics.weather_sales_corr(calc_date DESC);

-- 임베딩 처리 이력 (중복 임베딩 방지)
CREATE TABLE IF NOT EXISTS analytics.embedding_log (
    id           SERIAL PRIMARY KEY,
    source_type  VARCHAR(50),   -- 'weather', 'sales'
    source_id    BIGINT,
    embedded_at  TIMESTAMP DEFAULT NOW(),
    UNIQUE (source_type, source_id)
);

DO $$
BEGIN
    RAISE NOTICE '=== analytics 스키마 초기화 완료 ===';
    RAISE NOTICE '  analytics.weather_sales_corr';
    RAISE NOTICE '  analytics.embedding_log';
END $$;
