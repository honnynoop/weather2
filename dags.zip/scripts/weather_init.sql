-- ============================================================
-- weather_init.sql
-- 기존 MDS 환경에 Weather 기능 추가 (airflow DB 내 weather 스키마)
-- 실행: docker exec mds_postgres psql -U airflow -d airflow -f /weather_init.sql
-- ============================================================

\connect airflow;

-- ────────────────────────────────────────────
-- 1. weather 스키마 생성 (이미 있으면 무시)
-- ────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS weather;

-- ────────────────────────────────────────────
-- 2. 날씨 수집 테이블 (누적 저장)
-- ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS weather.weather_data (
    id              SERIAL PRIMARY KEY,
    city            VARCHAR(100)  NOT NULL,
    country         VARCHAR(10),
    description     VARCHAR(200),
    temperature_c   NUMERIC(5,2),
    feels_like_c    NUMERIC(5,2),
    temp_min_c      NUMERIC(5,2),
    temp_max_c      NUMERIC(5,2),
    pressure_hpa    INTEGER,
    humidity_pct    INTEGER,
    wind_speed_ms   NUMERIC(6,2),
    wind_deg        INTEGER,
    visibility_m    INTEGER,
    cloudiness_pct  INTEGER,
    time_of_record  TIMESTAMP,
    sunrise_time    TIMESTAMP,
    sunset_time     TIMESTAMP,
    collected_at    TIMESTAMP DEFAULT NOW()
);

-- ────────────────────────────────────────────
-- 3. 조회 성능 인덱스
-- ────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_weather_city
    ON weather.weather_data(city);

CREATE INDEX IF NOT EXISTS idx_weather_collected
    ON weather.weather_data(collected_at DESC);

CREATE INDEX IF NOT EXISTS idx_weather_city_time
    ON weather.weather_data(city, collected_at DESC);

-- ────────────────────────────────────────────
-- 4. 도시별 최신 데이터를 빠르게 보는 뷰
-- ────────────────────────────────────────────
CREATE OR REPLACE VIEW weather.v_latest_weather AS
SELECT DISTINCT ON (city)
    id,
    city,
    country,
    description,
    temperature_c,
    feels_like_c,
    temp_min_c,
    temp_max_c,
    pressure_hpa,
    humidity_pct,
    wind_speed_ms,
    wind_deg,
    visibility_m,
    cloudiness_pct,
    time_of_record,
    sunrise_time,
    sunset_time,
    collected_at
FROM weather.weather_data
ORDER BY city, collected_at DESC;

-- ────────────────────────────────────────────
-- 5. 시간별 도시 평균 통계 뷰 (Superset 차트용)
-- ────────────────────────────────────────────
CREATE OR REPLACE VIEW weather.v_hourly_stats AS
SELECT
    date_trunc('hour', collected_at)    AS hour_bucket,
    city,
    COUNT(*)                            AS sample_count,
    ROUND(AVG(temperature_c)::numeric, 2) AS avg_temp_c,
    ROUND(MIN(temperature_c)::numeric, 2) AS min_temp_c,
    ROUND(MAX(temperature_c)::numeric, 2) AS max_temp_c,
    ROUND(AVG(humidity_pct)::numeric, 1)  AS avg_humidity,
    ROUND(AVG(wind_speed_ms)::numeric, 2) AS avg_wind_ms,
    ROUND(AVG(pressure_hpa)::numeric, 1)  AS avg_pressure
FROM weather.weather_data
GROUP BY 1, 2
ORDER BY 1 DESC, 2;

-- ────────────────────────────────────────────
-- 6. 완료 확인
-- ────────────────────────────────────────────
DO $$
BEGIN
    RAISE NOTICE '=== Weather 스키마 초기화 완료 ===';
    RAISE NOTICE '  스키마  : weather';
    RAISE NOTICE '  테이블  : weather.weather_data';
    RAISE NOTICE '  뷰      : weather.v_latest_weather';
    RAISE NOTICE '  뷰      : weather.v_hourly_stats';
END $$;
