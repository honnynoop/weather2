"""
DAG: dbt 선택적 모델 재실행 (수동 트리거 전용)
==============================================
특정 모델만 재실행하거나 테스트만 돌릴 때 사용
schedule : None (수동 트리거 전용)
dbt 경로  : /opt/dbt
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

DBT_DIR = "/opt/dbt"

default_args = {
    "owner"           : "data_team",
    "depends_on_past" : False,
    "retries"         : 0,
    "email_on_failure": False,
}

with DAG(
    dag_id           = "dbt_selective_run",
    default_args     = default_args,
    description      = "dbt 선택적 모델 재실행 (수동 트리거 전용)",
    schedule_interval= None,               # 수동 트리거만
    start_date       = datetime(2024, 1, 1),
    catchup          = False,
    tags             = ["dbt", "manual", "data_stack"],
    params           = {
        "select": "marts",                 # 기본값: marts 전체
        "exclude": "",                     # 제외할 모델 (선택)
    },
) as dag:

    # ── 선택 모델만 실행 ──────────────────────────────────
    t_run = BashOperator(
        task_id      = "dbt_run_selected",
        bash_command = (
            f"cd {DBT_DIR} && "
            "dbt run --select {{ params.select }}"
            "{% if params.exclude %} --exclude {{ params.exclude }}{% endif %}"
        ),
    )

    # ── 선택 모델 테스트 ──────────────────────────────────
    t_test = BashOperator(
        task_id      = "dbt_test_selected",
        bash_command = (
            f"cd {DBT_DIR} && "
            "dbt test --select {{ params.select }}"
        ),
    )

    t_run >> t_test
