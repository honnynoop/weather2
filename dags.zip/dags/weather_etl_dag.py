"""
weather_etl_dag.py
==================
기존 MDS Docker 환경에 날씨 ETL을 추가하는 DAG

✅ 기존 환경과의 통합 포인트:
   - postgres_default  : 기존 등록된 Connection 재사용 (airflow DB)
   - airflow DB        : weather 스키마에 데이터 저장
   - Airflow Variable  : openweather_api_key (재빌드 없이 관리)

✅ ETL 흐름 (도시별 병렬):
   HttpSensor → SimpleHttpOperator → PythonOperator(변환+저장)

✅ 기존 테이블과 무관:
   raw.customers / raw.orders 등 기존 테이블에 영향 없음

수집 도시: 환경변수 또는 Variable 'weather_cities' (기본: Seoul,Busan,Incheon,Daegu)
스케줄: 매 1시간
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.providers.http.sensors.http import HttpSensor
from airflow.providers.postgres.hooks.postgres import PostgresHook

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# 설정 — Airflow Variable에서 읽어옴
#   설정 방법: Airflow UI → Admin → Variables → 추가
#             또는 apply_weather.sh 스크립트가 자동 등록
# ─────────────────────────────────────────────────────────────
def _get_api_key() -> str:
    """Airflow Variable에서 API 키를 읽어온다. 없으면 빈 문자열 반환."""
    try:
        return Variable.get("openweather_api_key")
    except KeyError:
        logger.error(
            "Airflow Variable 'openweather_api_key' 가 설정되지 않았습니다. "
            "apply_weather.sh 를 실행하거나 UI에서 직접 추가하세요."
        )
        return ""


def _get_cities() -> list[str]:
    """
    Airflow Variable 'weather_cities' 에서 도시 목록을 읽어온다.
    Variable이 없으면 기본값 사용.
    """
    try:
        cities_str = Variable.get("weather_cities")
    except KeyError:
        cities_str = "Seoul,Busan,Incheon,Daegu"
    return [c.strip() for c in cities_str.split(",") if c.strip()]


# ─────────────────────────────────────────────────────────────
# 유틸리티
# ─────────────────────────────────────────────────────────────
def _kelvin_to_celsius(k: float) -> float:
    """켈빈 → 섭씨"""
    return round(float(k) - 273.15, 2)


def _safe(d: dict, *keys, default=None):
    """중첩 dict 안전 접근"""
    for key in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(key, default)
    return d


# ─────────────────────────────────────────────────────────────
# Task 함수: 변환 + PostgreSQL 저장
# ─────────────────────────────────────────────────────────────
def transform_and_load(city: str, **context) -> None:
    """
    XCom에서 API 응답을 가져와 변환 후 weather.weather_data에 저장.

    Parameters
    ----------
    city : str
        도시명 (extract 태스크 ID 구성에 사용)
    context : dict
        Airflow 컨텍스트 (task_instance 포함)
    """
    ti = context["task_instance"]
    raw: dict = ti.xcom_pull(task_ids=f"extract_weather_{city}")

    if not raw:
        raise ValueError(
            f"[{city}] XCom 데이터가 없습니다. "
            f"extract_weather_{city} 태스크의 결과를 확인하세요."
        )

    # ── 변환 ──────────────────────────────────────────────────
    city_name      = raw.get("name", city)
    country        = _safe(raw, "sys", "country", default="")
    weather_list   = raw.get("weather", [{}])
    description    = weather_list[0].get("description", "") if weather_list else ""

    main           = raw.get("main", {})
    temp_c         = _kelvin_to_celsius(main.get("temp",       273.15))
    feels_like_c   = _kelvin_to_celsius(main.get("feels_like", 273.15))
    temp_min_c     = _kelvin_to_celsius(main.get("temp_min",   273.15))
    temp_max_c     = _kelvin_to_celsius(main.get("temp_max",   273.15))
    pressure_hpa   = int(main.get("pressure", 0))
    humidity_pct   = int(main.get("humidity", 0))

    wind           = raw.get("wind", {})
    wind_speed_ms  = float(wind.get("speed", 0.0))
    wind_deg       = int(wind.get("deg", 0))

    visibility_m   = int(raw.get("visibility", 0))
    cloudiness_pct = int(_safe(raw, "clouds", "all", default=0))

    tz_offset      = raw.get("timezone", 0)
    time_of_record = datetime.utcfromtimestamp(raw.get("dt", 0) + tz_offset)
    sunrise_time   = datetime.utcfromtimestamp(
                        (_safe(raw, "sys", "sunrise") or 0) + tz_offset)
    sunset_time    = datetime.utcfromtimestamp(
                        (_safe(raw, "sys", "sunset")  or 0) + tz_offset)

    logger.info(
        "[%s(%s)] %.1f°C | %s | 습도 %d%% | 풍속 %.1f m/s",
        city_name, country, temp_c, description, humidity_pct, wind_speed_ms,
    )

    # ── PostgreSQL 저장 (기존 postgres_default 커넥션 사용) ───
    hook = PostgresHook(postgres_conn_id="postgres_mds")
    hook.run(
        """
        INSERT INTO weather.weather_data (
            city, country, description,
            temperature_c, feels_like_c, temp_min_c, temp_max_c,
            pressure_hpa,  humidity_pct,
            wind_speed_ms, wind_deg,
            visibility_m,  cloudiness_pct,
            time_of_record, sunrise_time, sunset_time
        ) VALUES (
            %s, %s, %s,
            %s, %s, %s, %s,
            %s, %s,
            %s, %s,
            %s, %s,
            %s, %s, %s
        )
        """,
        parameters=(
            city_name, country, description,
            temp_c, feels_like_c, temp_min_c, temp_max_c,
            pressure_hpa, humidity_pct,
            wind_speed_ms, wind_deg,
            visibility_m, cloudiness_pct,
            time_of_record, sunrise_time, sunset_time,
        ),
    )
    logger.info("[%s] weather.weather_data 저장 완료 ✓", city_name)


# ─────────────────────────────────────────────────────────────
# DAG 정의
# ─────────────────────────────────────────────────────────────
default_args = {
    "owner":            "airflow",
    "depends_on_past":  False,
    "start_date":       datetime(2024, 1, 1),
    "email_on_failure": False,
    "email_on_retry":   False,
    "retries":          2,
    "retry_delay":      timedelta(minutes=5),
}

with DAG(
    dag_id="weather_etl_pipeline",
    default_args=default_args,
    description="OpenWeatherMap API → weather.weather_data (MDS 기존 환경 통합)",
    schedule_interval="@hourly",
    catchup=False,
    max_active_runs=1,
    tags=["weather", "etl", "openweathermap"],
) as dag:

    dag.doc_md = """
    ## Weather ETL Pipeline (MDS 통합 버전)

    **데이터 흐름**
    ```
    OpenWeatherMap API
      → HttpSensor (API 상태 확인)
      → SimpleHttpOperator (JSON 응답 추출)
      → PythonOperator (Kelvin→°C 변환 + PostgreSQL 저장)
    ```

    **저장 위치**
    - DB: `airflow` (기존 postgres_default 커넥션)
    - 스키마: `weather`
    - 테이블: `weather.weather_data`

    **설정 (Airflow Variables)**
    | Variable | 설명 | 예시 |
    |---|---|---|
    | `openweather_api_key` | API 키 (필수) | `abc123...` |
    | `weather_cities` | 수집 도시 목록 | `Seoul,Busan,Incheon,Daegu` |

    **스케줄**: 매 1시간 (`@hourly`)
    """

    # ── 런타임에 Variable 읽기 ─────────────────────────────
    # (DAG 파싱 시점이 아닌 실행 시점에 읽어야 Variable이 적용됨)
    CITIES = _get_cities()

    # 도시 목록이 비어 있으면 안전하게 기본값 사용
    if not CITIES:
        CITIES = ["Seoul", "Busan", "Incheon", "Daegu"]

    # ── 도시별 태스크 체인 동적 생성 (병렬 실행) ──────────
    for city in CITIES:

        api_key = _get_api_key()
        endpoint = f"/data/2.5/weather?q={city}&appid={api_key}&units=standard"

        # Task 1 — API 가용성 확인 (HttpSensor)
        is_api_ready = HttpSensor(
            task_id=f"is_api_ready_{city}",
            http_conn_id="weathermap_api",  # apply_weather.sh 가 등록
            endpoint=endpoint,
            response_check=lambda resp: resp.status_code == 200,
            poke_interval=15,
            timeout=60,
            mode="reschedule",  # 슬롯 점유 없이 대기
        )

        # Task 2 — 날씨 JSON 추출 (SimpleHttpOperator)
        extract_weather = SimpleHttpOperator(
            task_id=f"extract_weather_{city}",
            http_conn_id="weathermap_api",
            endpoint=endpoint,
            method="GET",
            response_filter=lambda r: json.loads(r.text),
            log_response=True,
        )

        # Task 3 — 변환 + PostgreSQL 저장 (PythonOperator)
        transform_load = PythonOperator(
            task_id=f"transform_load_{city}",
            python_callable=transform_and_load,
            op_kwargs={"city": city},
        )

        # 체인: 확인 → 추출 → 저장
        is_api_ready >> extract_weather >> transform_load
